package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class PIMPage {
	WebDriver ldriver;

	public PIMPage(WebDriver rdDriver) {
		ldriver = rdDriver;
		PageFactory.initElements(rdDriver, this);
	}
	@FindBy (xpath = "//b[contains(text(),'PIM')]")
	WebElement PIMTab;
	
	@FindBy (id = "empsearch_employee_name_empName")
	WebElement employeeName;
	
	
	public void clickonPIM() {
		PIMTab.click();
	}
	public void enterempName(String empname) {
		employeeName.sendKeys(empname);
	}
		
		
}
