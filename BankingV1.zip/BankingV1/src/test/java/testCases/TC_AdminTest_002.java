package testCases;

import org.apache.log4j.Logger;
import org.testng.annotations.Test;

import pageObjects.AdminPage;
import utilities.Reporting;

public class TC_AdminTest_002 extends BaseClass {
	
	private Reporting reporting = Reporting.getAppLogger(TC_AdminTest_002.class.getName());
	

	@Test
	public void Adminusersearch() throws Exception {

		TC_LoginTest_001 t = new TC_LoginTest_001();
		t.loginTest();
		Thread.sleep(3000);

		AdminPage ad = new AdminPage(driver);
		ad.clickonAdmintab();
		ad.enteruserName("hannah.flores");
		reporting.fatalLog("Test case TC_002 Passed");
		ad.clickonSearch();
	}

}
