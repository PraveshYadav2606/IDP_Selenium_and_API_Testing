import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_001_GET_Request {

	@Test
	void Weatherdetails() {
		// Specify base URI (1. Define the base URI)
		RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city/";

		// Request object (2. Create the request object)
		RequestSpecification httprequest = RestAssured.given();

		// Response object (3. Create the response object)
		Response response = httprequest.request(Method.GET, "/Hyderabad");

		// print response in console window (4. Response body)
		String responseBody = response.getBody().asString();
		System.out.println("Response body is :" + responseBody);
		
		//verify the status code
		int statusCode = response.getStatusCode();
		System.out.println("Status code is:"+ statusCode);
		Assert.assertEquals(statusCode, 200);
		
		//Status line verification
		String statusLine = response.getStatusLine();
		System.out.println("Status line is:"+ statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
	}

}
