package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminPage {
WebDriver ldriver;
	
	public AdminPage(WebDriver rdriver){
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//b[contains(text(),'Admin')]")
	@CacheLookup
	WebElement adminTab;
	
	@FindBy(id="searchSystemUser_userName")
	@CacheLookup
	WebElement usernameEnter;
	
	@FindBy(id="searchBtn")
	@CacheLookup
	WebElement searchBtn;
	

public void clickonAdmintab() {
	adminTab.click();
}
public void enteruserName(String userNm) {
	usernameEnter.sendKeys(userNm);
}
public void clickonSearch() {
	searchBtn.click();
}

}
