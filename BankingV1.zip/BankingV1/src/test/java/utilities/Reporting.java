package utilities;

import org.apache.log4j.HTMLLayout;
import org.apache.log4j.PropertyConfigurator;
import org.apache.logging.log4j.LogManager;

public class Reporting extends HTMLLayout{
	
	private org.apache.logging.log4j.Logger logger;
	static final String path = "log4j.properties";
	
	protected Reporting(final String loggerName) {
		this.logger = LogManager.getLogger(loggerName);
	}
	
	public static Reporting getAppLogger(final String loggerName) {
		return new Reporting(loggerName);
	}
	
	public boolean fatalLog(final String description) throws Exception {
		
		try {
			PropertyConfigurator.configure(Reporting.path);
			this.logger.fatal(description);
			return true;
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	public boolean warningLog(final String description) throws Exception {
		
		try {
			PropertyConfigurator.configure(Reporting.path);
			this.logger.warn(description);
			return true;
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	public boolean debugLog(final String description) throws Exception {
		
		try {
			PropertyConfigurator.configure(Reporting.path);
			this.logger.debug(description);
			return true;
		}
		
		catch(Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

}
