import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_002_POST_Request {
	
	@Test
	void RegistrationSuccessful() {
		// Specify base URI
		RestAssured.baseURI = "http://restapi.demoqa.com/customer";

		// Request object
		RequestSpecification httprequest = RestAssured.given();

		// Response object
		JSONObject requestParams = new JSONObject();
		requestParams.put("FirstName", "John2");
		requestParams.put("LastName", "Wick");
		requestParams.put("UserName", "JohnWick1@23");
		requestParams.put("Password", "John@123");
		requestParams.put("Email", "Johnff@gmail.com");
		
		//Need to add header because we should know which type of data it is.
		httprequest.header("Content-Type", "application/json");
		
		//request params conver to json and sent to the body
		httprequest.body(requestParams.toJSONString());
		
		//Response objcet
		Response response  = httprequest.request(Method.POST, "/register");
		
		// print response in console window
		String responseBody = response.getBody().asString();
		System.out.println("Response body is :" + responseBody);
		
		//verify the status code
		int statusCode = response.getStatusCode();
		System.out.println("Status code is:"+ statusCode);
		Assert.assertEquals(statusCode, 201);
		
		//Success code validation
		String successCode = response.jsonPath().get("SuccessCode");
		Assert.assertEquals(successCode, "OPERATION_SUCCESS");
	}

}
