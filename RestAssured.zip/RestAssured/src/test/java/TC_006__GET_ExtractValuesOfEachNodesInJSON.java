import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC_006__GET_ExtractValuesOfEachNodesInJSON {
	
	@Test
	void GetWeatherDetails() {
		// Specify base URI
		RestAssured.baseURI = "http://restapi.demoqa.com/utilities/weather/city/";

		// Request object
		RequestSpecification httprequest = RestAssured.given();

		// Response object - Response is status code, response body, status line, response time, headers
		Response response = httprequest.request(Method.GET, "Delhi");
		
		//json path give the complete json in output
		JsonPath jsonpath = response.jsonPath();
		System.out.println(jsonpath.get("City"));
		Assert.assertEquals(jsonpath.get("City"), "Delhi");
		

}
}