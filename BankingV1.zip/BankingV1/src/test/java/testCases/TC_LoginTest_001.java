package testCases;
import utilities.Reporting;
import org.apache.logging.log4j.*;
import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.LoginPage;

public class TC_LoginTest_001 extends BaseClass {
	private static Logger log = LogManager.getLogger(TC_LoginTest_001.class.getName());
	private Reporting reporting = Reporting.getAppLogger(TC_LoginTest_001.class.getName());
	// child extends p1, p2, p3

	@Test
	public void loginTest() throws Exception {
		
		//Logger.info("URL is opened");
		log.info("URL is opened");
		LoginPage lp = new LoginPage(driver);
		lp.setUsername(username);
		//Logger.info("Enter username");
		reporting.fatalLog("Test case TC_001 Passed");
		lp.setPassword(password);
		//Logger.info("Enter Password");
		lp.clickonLogin();
		
		if(driver.getTitle().equals("OrangeHRM")) {
			Assert.assertTrue(true);
		}
		else
		{
			Assert.assertTrue(false);
		}
	}
	
	
}
